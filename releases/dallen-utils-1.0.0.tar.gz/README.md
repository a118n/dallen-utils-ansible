# Ansible Collection - dallen.utils

This is a sample collection with one simple module file_create which creates a file with content, specified by user.

Usage:
```sh
git clone https://github.com/a118n/dallen-utils-ansible.git
cd dallen-utils-ansible
ansible-galaxy collection install releases/dallen-utils-1.0.0.tar.gz
ansible-playbook ./test-module.yml
cat /tmp/test.txt
```
