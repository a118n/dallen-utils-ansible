# Ansible Collection - dallen.utils

This is a sample collection with one simple module file_create which creates a file with content, specified by user.
